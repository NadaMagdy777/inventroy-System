﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace inventroy_system
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

       

        private void ProductBtn_Click(object sender, RoutedEventArgs e)
        {
            contentWindow.Children.Clear();
            ProductsWindow productsWindow= new ProductsWindow();
            contentWindow.Children.Add(productsWindow);


        }

        private void CustomerBtn_Click(object sender, RoutedEventArgs e)
        {
            contentWindow.Children.Clear();
            CustomersWindow customersWindow= new CustomersWindow();
            contentWindow.Children.Add(customersWindow);

        }

        private void OrderBtn_Click(object sender, RoutedEventArgs e)
        {
            contentWindow.Children.Clear();
            OrdersWindow orderWindow= new OrdersWindow();
            contentWindow.Children.Add(orderWindow);
        }

        private void CatogryBtn_Click(object sender, RoutedEventArgs e)
        {
            contentWindow.Children.Clear();
            CategoryWindow categoryWindow= new CategoryWindow();
            contentWindow.Children.Add(categoryWindow);

        }

        private void UserBtn_Click(object sender, RoutedEventArgs e)
        {
            contentWindow.Children.Clear();
            UserWindow userWindow = new UserWindow();
            contentWindow.Children.Add(userWindow);
        }

        private void SupplierBtn_ContextMenuClosing(object sender, ContextMenuEventArgs e)
        {

        }

        private void SupplierBtn_Click(object sender, RoutedEventArgs e)
        {
            contentWindow.Children.Clear();
            SuppliersWindow suppliersWindow = new SuppliersWindow();
            contentWindow.Children.Add(suppliersWindow);

        }
    }
}
